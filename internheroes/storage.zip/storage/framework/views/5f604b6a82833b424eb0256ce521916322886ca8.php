<li class="nav-item  "> <a href="javascript:;" class="nav-link nav-toggle"> <i class="icon-user"></i> <span class="title">User Profiles</span> <span class="arrow"></span> </a>
    <ul class="sub-menu">
        <li class="nav-item  "> <a href="<?php echo e(route('list.users')); ?>" class="nav-link "> <i class="icon-user"></i> <span class="title">List User Profiles</span> </a> </li>
        <li class="nav-item  "> <a href="<?php echo e(route('create.user')); ?>" class="nav-link "> <i class="icon-user"></i> <span class="title">Add new User Profile</span> </a> </li>
    </ul>
</li>