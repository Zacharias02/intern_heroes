<li class="nav-item  "> <a href="javascript:;" class="nav-link nav-toggle"> <i class="fa fa-file-text-o" aria-hidden="true"></i> <span class="title">Degree Types</span> <span class="arrow"></span> </a>
    <ul class="sub-menu">
        <li class="nav-item  "> <a href="<?php echo e(route('list.degree.types')); ?>" class="nav-link "> <span class="title">List Degree Types</span> </a> </li>
        <li class="nav-item  "> <a href="<?php echo e(route('create.degree.type')); ?>" class="nav-link "> <span class="title">Add new Degree Type</span> </a> </li>
        <li class="nav-item  "> <a href="<?php echo e(route('sort.degree.types')); ?>" class="nav-link "> <span class="title">Sort Degree Types</span> </a> </li>
    </ul>
</li>