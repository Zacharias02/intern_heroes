
<?php $__env->startSection('content'); ?>
<!-- Header start -->
<?php echo $__env->make('includes.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<!-- Header end --> 
<!-- Inner Page Title start -->
<?php echo $__env->make('includes.inner_page_title', ['page_title'=>__('Company Posted Jobs')], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<!-- Inner Page Title end -->
<div class="listpgWraper">
    <div class="container">
        <div class="row">
            <?php echo $__env->make('includes.company_dashboard_menu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

            <div class="col-md-9 col-sm-8"> 
                <div class="myads">
                    <h3><?php echo e(__('Company Posted Jobs')); ?></h3>
                    <ul class="row searchList">
                        <!-- job start --> 
                        <?php if(isset($jobs) && count($jobs)): ?>
                        <?php $__currentLoopData = $jobs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $job): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php $company = $job->getCompany(); ?>
                        <?php if(null !== $company): ?>
                        <li class="col-md-12 col-sm-12 two-col" id="job_li_<?php echo e($job->id); ?>">
                            <div class="job-details">
                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="media">
                                            <div class="media-left">
                                                <div class="jobimg">
                                                    <a href="<?php echo e(route('job.detail', [$job->slug])); ?>" title="<?php echo e($job->title); ?>"> 
                                                        <span style="background-image: url(<?php echo e($company->getCompanyImage()); ?>)"></span>
                                                    </a>
                                                </div>
                                            </div>
                                            <div class="media-body">
                                                <div class="jobinfo">
                                                    <h3><a href="<?php echo e(route('job.detail', [$job->slug])); ?>" title="<?php echo e($job->title); ?>"><?php echo e($job->title); ?></a></h3>
                                                    <div class="companyName"><a href="<?php echo e(route('company.detail', $company->slug)); ?>" title="<?php echo e($company->name); ?>"><?php echo e($company->name); ?></a></div>
                                                    <div class="location">
                                                        <span><?php echo e($job->getCity('city')); ?></span>
                                                    </div>
                                                    <div>
                                                        <label class="fulltime" title="<?php echo e($job->getJobType('job_type')); ?>"><?php echo e($job->getJobType('job_type')); ?></label>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    <!--  <div class="jobimg"><?php echo e($company->printCompanyImage()); ?></div>
                                        <div class="jobinfo">
                                            <h3><a href="<?php echo e(route('job.detail', [$job->slug])); ?>" title="<?php echo e($job->title); ?>"><?php echo e($job->title); ?></a></h3>
                                            <div class="companyName"><a href="<?php echo e(route('company.detail', $company->slug)); ?>" title="<?php echo e($company->name); ?>"><?php echo e($company->name); ?></a></div>
                                            <div class="location">
                                                <label class="fulltime" title="<?php echo e($job->getJobShift('job_shift')); ?>"><?php echo e($job->getJobShift('job_shift')); ?></label>
                                                - <span><?php echo e($job->getCity('city')); ?></span>
                                            </div>
                                        </div> -->
                                        <div class="job-action-list">
                                            <i class="fa fa-chevron-circle-down dropdown-toggle"></i>
                                            <ul class="dropdown-menu">
                                                <li><a href="<?php echo e(route('list.favourite.applied.users', [$job->id])); ?>"><?php echo e(__('View Short Listed Candidates')); ?></a></li>
                                                <li><a round" href="<?php echo e(route('list.applied.users', [$job->id])); ?>"><?php echo e(__('View Candidates')); ?></a></li>
                                                <li><a href="<?php echo e(route('edit.front.job', [$job->id])); ?>"><?php echo e(__('Edit')); ?></a></li>
                                                <li><a href="javascript:;" onclick="deleteJob(<?php echo e($job->id); ?>);"><?php echo e(__('Delete')); ?></a></li>
                                            </ul>
                                        </div>
                                    </div>
                                <!--  <div class="col-md-5 col-sm-5">                
                                        <div class="listbtn"><a class="btn btn-primary no-fill round" href="<?php echo e(route('list.favourite.applied.users', [$job->id])); ?>"><?php echo e(__('View Short Listed Candidates')); ?></a></div>
                                        <div class="listbtn"><a class="btn btn-primary no-fill round" href="<?php echo e(route('list.applied.users', [$job->id])); ?>"><?php echo e(__('View Candidates')); ?></a></div>
                                        <div class="listbtn"><a class="btn btn-primary no-fill round" href="<?php echo e(route('edit.front.job', [$job->id])); ?>"><?php echo e(__('Edit')); ?></a></div>
                                        <div class="listbtn"><a class="btn btn-primary no-fill round" href="javascript:;" onclick="deleteJob(<?php echo e($job->id); ?>);"><?php echo e(__('Delete')); ?></a></div>
                                    </div> -->
                                </div>
                            <p><?php echo e(str_limit(strip_tags($job->description), 150, '...')); ?></p>
                            </div>
                        </li>
                        <!-- job end --> 
                        <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    </ul>
                    <?php if(count($jobs) <= 0): ?>
                        <div class="empty-state">
                            <span class="empty-state-icon job"></span>
                            <h4 class="empty-state-title">There are no jobs available</h4>
                            <p></p>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>
<?php echo $__env->make('includes.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
<script type="text/javascript">
    $(function() {
        // Dropdown toggle
        $('.dropdown-toggle').click(function(){
            $(this).next('.dropdown-menu').toggle();
        });

        $(document).click(function(e) {
            var target = e.target;
            if (!$(target).is('.dropdown-toggle') && !$(target).parents().is('.dropdown-toggle')) {
                $('.dropdown-menu').hide();
            }
        });

    });


    function deleteJob(id) {
        var msg = 'Are you sure you want permanently remove this Job Post?';
        if (confirm(msg)) {
        $.post("<?php echo e(route('delete.front.job')); ?>", {id: id, _method: 'DELETE', _token: '<?php echo e(csrf_token()); ?>'})
                .done(function (response) {
                if (response == 'ok')
                {
                $('#job_li_' + id).remove();
                } else
                {
                alert('Request Failed!');
                }
                });
        }
    }
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>