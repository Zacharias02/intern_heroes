
<?php $__env->startSection('content'); ?>
<!-- Header start -->
<?php echo $__env->make('includes.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<!-- Header end --> 
<!-- Search start -->
<?php echo $__env->make('includes.search', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<!-- Search End --> 
<!-- Top Employers start -->
<?php echo $__env->make('includes.top_employers', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<!-- Top Employers ends --> 
<!-- Popular Searches start -->
<?php echo $__env->make('includes.popular_searches', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<!-- Popular Searches ends --> 

<!-- Featured Jobs start -->
<?php echo $__env->make('includes.featured_jobs', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<!-- Featured Jobs ends --> 

<!-- Latest Jobs start -->
<?php echo $__env->make('includes.latest_jobs', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<!-- Latest Jobs ends --> 

<!-- How it Works start -->
<?php echo $__env->make('includes.how_it_works', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<!-- How it Works Ends -->

<!-- Video start -->

<!-- Video end --> 

<!-- Testimonials start -->

<!-- Testimonials End -->
<!-- Subscribe start -->
<?php echo $__env->make('includes.subscribe', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<!-- Subscribe End -->
<?php echo $__env->make('includes.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?> 
<?php echo $__env->make('includes.country_state_city_js', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<script>
    $(document).ready(function () {
        $("form").submit(function () {
            $(this).find(":input").filter(function () {
                return !this.value;
            }).attr("disabled", "disabled");
            return true;
        });
        $("form").find(":input").prop("disabled", false);
    });
    $(document).ready(function () {
        var $testimonials = $('.testimonials');
        if ($testimonials.length > 0) {
            $('.texts > div:first-child').addClass('show');
            $('.selectors > span:first-child').addClass('show');
            setInterval(function() {
                $testimonials.find('.images span').each(function() {
                    var $this = $(this);
                    // if ($this.hasClass('step-0')) {
                    //     $this.removeClass('step-0').addClass('step-1');
                    // } else if ($this.hasClass('step-1')) {
                    //     $this.removeClass('step-1').addClass('step-2');
                    // } else 
                    if ($this.hasClass('step-2')) {
                        $this.removeClass('step-2').addClass('step-3');
                    } else if ($this.hasClass('step-3')) {
                        $this.removeClass('step-3').addClass('step-2');
                    } 
                    // else if ($this.hasClass('step-4')) {
                    //     $this.removeClass('step-4').addClass('step-0');
                    // }
                });
                var index = $testimonials.find('.images span.step-3').index();
                $testimonials.find('.selectors > span').each(function() {
                    var $this = $(this);
                    if ($this.index() === index) {
                        $this.addClass('show');
                    } else {
                        $this.removeClass('show');
                    }
                });
                $testimonials.find('.texts > div').each(function() {
                    var $this = $(this);
                    if ($this.index() === index) {
                        $this.addClass('show');
                    } else {
                        $this.removeClass('show');
                    }
                });
            }, 10000);
        }
    });
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>