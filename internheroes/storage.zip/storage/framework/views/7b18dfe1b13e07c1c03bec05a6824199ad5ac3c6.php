<ul class="row profilestat">
    <li class="col-md-4 col-sm-12 col-xs-12">
        <div class="inbox"> 
            <div class="media">
                <div class="media-left">
                    <i class="fa fa-clock-o" aria-hidden="true"></i>
                </div>
                <div class="media-body">
                    <h6><a href="<?php echo e(route('posted.jobs')); ?>"><?php echo e(Auth::guard('company')->user()->countOpenJobs()); ?> <?php echo e(__('Open Jobs')); ?></a></h6>
                </div>
            </div>
        </div>
    </li>
    <li class="col-md-4 col-sm-12 col-xs-12">
        <div class="inbox"> 
            <div class="media">
                <div class="media-left">
                    <i class="fa fa-user-o" aria-hidden="true"></i>
                </div>
                <div class="media-body">
                    <h6>
                        <a href="<?php echo e(route('company.followers')); ?>">
                            <?php echo e(Auth::guard('company')->user()->countFollowers()); ?> 
                            <?php if(Auth::guard('company')->user()->countFollowers() > 1): ?>
                            <?php echo e(__('Followers')); ?>

                            <?php else: ?>
                            <?php echo e(__('Follower')); ?>

                            <?php endif; ?>
                        </a>
                    </h6>
                </div>
            </div>
        </div>
    </li>
    <!-- <li class="col-md-4 col-sm-4 col-xs-6">
        <div class="inbox"> 
            <div class="media">
                <div class="media-left">
                    <i class="fa fa-envelope-o" aria-hidden="true"></i>
                </div>
                <div class="media-body">
                    <h6><a href="<?php echo e(route('company.messages')); ?>"><?php echo e(Auth::guard('company')->user()->countCompanyMessages()); ?> <?php echo e(__('Messages')); ?></a></h6>
                </div>
            </div>
        </div>
    </li> -->
</ul>