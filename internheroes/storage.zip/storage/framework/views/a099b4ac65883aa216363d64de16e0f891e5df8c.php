

<div class="section p-0">
<div class="largebanner">
    <div class="adin">
    <?php echo $siteSetting->index_page_below_top_employes_ad; ?>

    </div>
    <div class="clearfix"></div>
</div>
</div>

<div class="section howitwrap mb-5">
    <div class="container">
        <!-- title start -->
        <div class="titleTop align-center">
            <!-- <div class="subtitle"><?php echo e(__('Here You Can See')); ?></div> -->
            <h3><?php echo e(__('How It')); ?> <span><?php echo e(__('Works')); ?></span></h3>
        </div>
        <!-- title end -->
        <ul class="howlist row" align="center">
            <!--step 1-->
            <li class="col-md-4 col-sm-4">
                <div class="how-it-work create">
                </div>
                <h4><?php echo e(__('Create An Account')); ?></h4>
                <p><?php echo e(__('Fill up a registration form to get your account access')); ?>.</p>
            </li>
            <!--step 1 end-->
            <!--step 2-->
            <li class="col-md-4 col-sm-4">
                <div class="how-it-work search">
                </div>
                <h4><?php echo e(__('Search Desired Job')); ?></h4>
                <p><?php echo e(__('Browse through the job lists or search specific job you are interested in')); ?>.</p>
            </li>
            <!--step 2 end-->
            <!--step 3-->
            <li class="col-md-4 col-sm-4">
                <div class="how-it-work send">
                </div>
                <h4><?php echo e(__('Send Your Resume')); ?></h4>
                <p><?php echo e(__('Prepare your resume, attach the file, and click send')); ?>!</p>
            </li>
            <!--step 3 end-->
        </ul>
    </div>
</div>