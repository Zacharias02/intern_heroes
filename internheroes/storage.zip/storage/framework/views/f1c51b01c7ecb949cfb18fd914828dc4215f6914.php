
<?php $__env->startSection('content'); ?> 
<!-- Header start --> 
<?php echo $__env->make('includes.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?> 
<!-- Header end --> 
<!-- Inner Page Title start --> 
<?php echo $__env->make('includes.inner_page_title', ['page_title'=>__('Register')], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?> 
<!-- Inner Page Title end -->
<div class="listpgWraper">
    <div class="container">
        <?php echo $__env->make('flash::message', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <div class="row">
            <div class="col-md-6 col-md-offset-3">
                <div class="userccount auth">
                    <div class="userbtns">
                        <ul class="nav nav-tabs">
                            <?php
                            $c_or_e = old('candidate_or_employer', 'candidate');
                            ?>
                            <li class="candidate <?php echo e(($c_or_e == 'candidate')? 'active':''); ?>">
                                <a data-toggle="tab" href="#candidate" aria-expanded="true">
                                    <span class="tab-title"><?php echo e(__('Candidate')); ?></span>
                                </a>
                                
                            </li>
                            <li class="employer <?php echo e(($c_or_e == 'employer')? 'active':''); ?>">
                                <a data-toggle="tab" href="#employer" aria-expanded="false">
                                    <span class="tab-title"><?php echo e(__('Employer')); ?></span>
                                </a>
                            </li>
                        </ul>
                    </div>
                    <div class="tab-content">
                        <div id="candidate" class="formpanel tab-pane fade <?php echo e(($c_or_e == 'candidate')? 'active in':''); ?>">
                            <form class="form-horizontal" method="POST" action="<?php echo e(route('register')); ?>">
                                <?php echo e(csrf_field()); ?>

                                <input type="hidden" name="candidate_or_employer" value="candidate" />
                                <div class="formrow<?php echo e($errors->has('first_name') ? ' has-error' : ''); ?>">
                                    <input type="text" name="first_name" class="form-control" required="required" value="<?php echo e(old('first_name')); ?>">
                                    <label><?php echo e(__('First Name')); ?></label>
                                    <?php if($errors->has('first_name')): ?> <span class="help-block"> <strong><?php echo e($errors->first('first_name')); ?></strong> </span> <?php endif; ?> </div>
                                <div class="formrow<?php echo e($errors->has('middle_name') ? ' has-error' : ''); ?>">
                                    <input type="text" name="middle_name" class="form-control" value="<?php echo e(old('middle_name')); ?>" required>
                                    <label><?php echo e(__('Middle Name')); ?></label>
                                    <?php if($errors->has('middle_name')): ?> <span class="help-block"> <strong><?php echo e($errors->first('middle_name')); ?></strong> </span> <?php endif; ?> </div>
                                <div class="formrow<?php echo e($errors->has('last_name') ? ' has-error' : ''); ?>">
                                    <input type="text" name="last_name" class="form-control" required="required" value="<?php echo e(old('last_name')); ?>">
                                    <label><?php echo e(__('Last Name')); ?></label>
                                    <?php if($errors->has('last_name')): ?> <span class="help-block"> <strong><?php echo e($errors->first('last_name')); ?></strong> </span> <?php endif; ?> </div>
                                <div class="formrow<?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
                                    <input type="text" name="email" class="form-control" required="required" value="<?php echo e(old('email')); ?>">
                                    <label><?php echo e(__('Email')); ?></label>
                                    <?php if($errors->has('email')): ?> <span class="help-block"> <strong><?php echo e($errors->first('email')); ?></strong> </span> <?php endif; ?> </div>
                                <div class="formrow<?php echo e($errors->has('password') ? ' has-error' : ''); ?>">
                                    <input type="password" id="password" name="password" class="form-control" required="required" value="">
                                    <label><?php echo e(__('Password')); ?></label>
                                    <span class="show-password toggle-password" toggle="#password"></span>
                                </div>
                                <div class="formrow<?php echo e($errors->has('password_confirmation') ? ' has-error' : ''); ?><?php echo e($errors->has('password') ? ' has-error' : ''); ?>">
                                    <input type="password" id="confirm-password" name="password_confirmation" class="form-control" required="required" value="">
                                    <label><?php echo e(__('Password Confirmation')); ?></label>
                                    <?php if($errors->has('password_confirmation')): ?> <span class="help-block"> <strong><?php echo e($errors->first('password_confirmation')); ?></strong> </span> <?php endif; ?>
                                    <?php if($errors->has('password')): ?> <span class="help-block"> <strong><?php echo e($errors->first('password')); ?></strong> </span> <?php endif; ?> 
                                    <span class="show-password toggle-password" toggle="#confirm-password"></span>
                                </div>
                                <div class="subscribe-check <?php echo e($errors->has('is_subscribed') ? ' has-error' : ''); ?>">
                                    <?php
                                    $is_checked = '';
                                    if (old('is_subscribed', 1)) {
                                        $is_checked = 'checked="checked"';
                                    }
                                    ?>
                                    <input type="checkbox" value="1" name="is_subscribed" <?php echo e($is_checked); ?> /><?php echo e(__('Subscribe to news letter')); ?>

                                    <?php if($errors->has('is_subscribed')): ?> <span class="help-block"> <strong><?php echo e($errors->first('is_subscribed')); ?></strong> </span> <?php endif; ?> 
                                </div>   
                                <div class="formrow terms-check <?php echo e($errors->has('terms_of_use') ? ' has-error' : ''); ?>">
                                    <input type="checkbox" value="1" name="terms_of_use" />
                                    <a href="<?php echo e(url('cms/terms-of-use')); ?>"><?php echo e(__('I accept the Terms and Conditions')); ?></a>

                                    <?php if($errors->has('terms_of_use')): ?> <span class="help-block"> <strong><?php echo e($errors->first('terms_of_use')); ?></strong> </span> <?php endif; ?> </div>
                                <div class="formrow<?php echo e($errors->has('g-recaptcha-response') ? ' has-error' : ''); ?>"> <?php echo app('captcha')->display(); ?>

                                    <?php if($errors->has('g-recaptcha-response')): ?> <span class="help-block"> <strong><?php echo e($errors->first('g-recaptcha-response')); ?></strong> </span> <?php endif; ?> </div>
                                <div class="row" align="center">
                                    <div class="col-md-6" style="float:none !important;">
                                        <input type="submit" class="btn btn-secondary round btn-block" value="<?php echo e(__('Create Account')); ?>">
                                    </div>
                                </div>
                            </form>
                            <!-- sign up form -->
                            <div class="newuser"><?php echo e(__('Have an Account')); ?>? <a class="btn btn-primary round no-fill" href="<?php echo e(route('login')); ?>"><?php echo e(__('Log in')); ?></a></div>
                            <!-- sign up form end--> 
                        </div>
                        <div id="employer" class="formpanel tab-pane fade <?php echo e(($c_or_e == 'employer')? 'active in':''); ?>">
                            <form class="form-horizontal" method="POST" action="<?php echo e(route('company.register')); ?>">
                                <?php echo e(csrf_field()); ?>

                                <input type="hidden" name="candidate_or_employer" value="employer" />
                                <div class="formrow<?php echo e($errors->has('name') ? ' has-error' : ''); ?>">
                                    <input type="text" name="name" class="form-control" required="required" value="<?php echo e(old('name')); ?>">
                                    <label><?php echo e(__('Name')); ?></label>
                                    <?php if($errors->has('name')): ?> <span class="help-block"> <strong><?php echo e($errors->first('name')); ?></strong> </span> <?php endif; ?> 
                                </div>
                                <div class="formrow<?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
                                    <input type="text" name="email" class="form-control" required="required" value="<?php echo e(old('email')); ?>">
                                    <label><?php echo e(__('Email')); ?></label>
                                    <?php if($errors->has('email')): ?> <span class="help-block"> <strong><?php echo e($errors->first('email')); ?></strong> </span> <?php endif; ?> 
                                </div>
                                <div class="formrow<?php echo e($errors->has('password') ? ' has-error' : ''); ?>">
                                    <input type="password"  id="pass" name="password" class="form-control" required="required" value="">
                                    <label><?php echo e(__('Password')); ?></label>
                                    
                                    <span class="show-password toggle-password" toggle="#pass"></span>
                                </div>
                                <div class="formrow<?php echo e($errors->has('password_confirmation') ? ' has-error' : ''); ?><?php echo e($errors->has('password') ? ' has-error' : ''); ?>">
                                    <input type="password" id="confirm-pass" name="password_confirmation" class="form-control" required="required" value="">
                                    <label><?php echo e(__('Password Confirmation')); ?></label>
                                    <?php if($errors->has('password_confirmation')): ?> <span class="help-block"> <strong><?php echo e($errors->first('password_confirmation')); ?></strong> </span> <?php endif; ?> 
                                    <?php if($errors->has('password')): ?> <span class="help-block"> <strong><?php echo e($errors->first('password')); ?></strong> </span> <?php endif; ?> 
                                    <span class="show-password toggle-password" toggle="#confirm-pass"></span>
                                </div>
                                <div class="subscribe-check <?php echo e($errors->has('is_subscribed') ? ' has-error' : ''); ?>">
                                    <?php
                                    $is_checked = '';
                                    if (old('is_subscribed', 1)) {
                                        $is_checked = 'checked="checked"';
                                    }
                                    ?>
                                    <input type="checkbox" value="1" name="is_subscribed" <?php echo e($is_checked); ?> /><?php echo e(__('Subscribe to news letter')); ?>

                                    <?php if($errors->has('is_subscribed')): ?> <span class="help-block"> <strong><?php echo e($errors->first('is_subscribed')); ?></strong> </span> <?php endif; ?>
                                </div>
                                <div class="formrow terms-check <?php echo e($errors->has('terms_of_use') ? ' has-error' : ''); ?>">
                                    <input type="checkbox" value="1" name="terms_of_use" />
                                    <a href="<?php echo e(url('cms/terms-of-use')); ?>"><?php echo e(__('I accept the Terms and Conditions')); ?></a>

                                    <?php if($errors->has('terms_of_use')): ?> <span class="help-block"> <strong><?php echo e($errors->first('terms_of_use')); ?></strong> </span> <?php endif; ?> </div>
                                <div class="formrow<?php echo e($errors->has('g-recaptcha-response') ? ' has-error' : ''); ?>"> <?php echo app('captcha')->display(); ?>

                                    <?php if($errors->has('g-recaptcha-response')): ?> <span class="help-block"> <strong><?php echo e($errors->first('g-recaptcha-response')); ?></strong> </span> <?php endif; ?> </div>
                                <div class="row" align="center">
                                    <div class="col-md-6" style="float:none !important;">
                                        <input type="submit" class="btn btn-secondary round btn-block" value="<?php echo e(__('Create Account')); ?>">
                                    </div>
                                </div>
                            </form>
                            <!-- sign up form -->
                            <div class="newuser"><?php echo e(__('Have an Account')); ?>? <a class="btn btn-primary round no-fill" href="<?php echo e(route('login')); ?>"><?php echo e(__('Log in')); ?></a></div>
                            <!-- sign up form end--> 
                        </div>
                    </div>
                    

                </div>
            </div>
        </div>
    </div>
</div>
<?php echo $__env->make('includes.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?> 
<?php $__env->startPush('scripts'); ?> 
<script>
    $(document).ready(function ($) {
        $(".toggle-password").click(function() {
            $(this).toggleClass("active");
            
            var input = $($(this).attr("toggle"));
            if (input.attr("type") == "password") {
                input.attr("type", "text");
            } else {
                input.attr("type", "password");
            }
        });
    });
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>