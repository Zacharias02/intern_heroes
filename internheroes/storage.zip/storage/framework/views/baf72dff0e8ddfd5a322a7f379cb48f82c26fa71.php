
<?php $__env->startSection('content'); ?> 
<!-- Header start --> 
<?php echo $__env->make('includes.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?> 
<!-- Header end --> 
<!-- Inner Page Title start --> 
<?php echo $__env->make('includes.inner_page_title', ['page_title'=>__('Company Details')], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?> 
<!-- Inner Page Title end -->
<div class="listpgWraper">
    <div class="container"> 
        <?php echo $__env->make('flash::message', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?> 
        <!-- Job Header start -->
        <div class="job-header">
            <div class="jobinfo">
                <div class="row">
                    <div class="col-md-6 col-sm-6"> 
                        <!-- Candidate Info -->
                        <div class="candidateinfo">
                            <div class="media">
                                <div class="media-left">
                                    <div class="userPic">
                                        <a href="<?php echo e(route('company.detail',$company->slug)); ?>">
                                            <span style="background-image: url(<?php echo e($company->getCompanyImage()); ?>)"></span>
                                        </a>
                                    </div>
                                </div>
                                <div class="media-body">
                                    <div class="title"><?php echo e($company->name); ?></div>
                                    <div class="desi"><?php echo e($company->getIndustry('industry')); ?></div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3 col-sm-3"> 
                        <!-- Candidate Contact -->
                        <div class="candidateinfo">
                            <div class="loctext"><i class="fa fa-history" aria-hidden="true"></i> <?php echo e(__('Member Since')); ?>, <?php echo e($company->created_at->format('M d, Y')); ?></div>
                            <div class="loctext"><i class="fa fa-map-marker" aria-hidden="true"></i> <?php echo e($company->location); ?></div>
                            <?php if(!empty($company->phone)): ?>
                            <div class="loctext"><i class="fa fa-phone" aria-hidden="true"></i> <a href="tel:<?php echo e($company->phone); ?>"><?php echo e($company->phone); ?></a></div>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="col-md-3 col-sm-3"> 
                        <!-- Candidate Contact -->
                        <div class="candidateinfo">
                            <?php if(!empty($company->email)): ?>
                            <div class="loctext"><i class="fa fa-envelope" aria-hidden="true"></i> <a href="mailto:<?php echo e($company->email); ?>"><?php echo e($company->email); ?></a></div>
                            <?php endif; ?>
                            <?php if(!empty($company->website)): ?>
                            <div class="loctext"><i class="fa fa-globe" aria-hidden="true"></i> <a href="<?php echo e($company->website); ?>" target="_blank"><?php echo e($company->website); ?></a></div>
                            <?php endif; ?>  
                            <div class="cadsocial"> <?php echo $company->getSocialNetworkHtml(); ?> </div>
                        </div>
                    </div>
                </div>
            </div>

            <?php if(!Auth::guard('company')->check()): ?>
                <!-- Buttons -->
                <div class="jobButtons"> 
                    <!-- <a href="#contact_company" class="btn btn-large btn-secondary round btn-strong text-uppercase apply">
                        <i class="fa fa-envelope-o" aria-hidden="true"></i> 
                        <?php echo e(__('Send Message')); ?>

                    </a>  -->
                    <?php if(Auth::check() && Auth::user()->isFavouriteCompany($company->slug)): ?> 
                        <a href="<?php echo e(route('remove.from.favourite.company', $company->slug)); ?>" class="btn">
                            <i class="fa fa-floppy-o" aria-hidden="true"></i> 
                            <?php echo e(__('Unsave Company')); ?> 
                        </a> 
                    <?php else: ?> 
                        <a href="<?php echo e(route('add.to.favourite.company', $company->slug)); ?>" class="btn">
                            <i class="fa fa-floppy-o" aria-hidden="true"></i> 
                            <?php echo e(__('Save this Company')); ?>

                        </a> 
                    <?php endif; ?> 
                    <?php if(!Auth::guard('company')->check()): ?>
                        <a href="<?php echo e(route('report.abuse.company', $company->slug)); ?>" class="btn report">
                            <i class="fa fa-exclamation-triangle" aria-hidden="true"></i> 
                            <?php echo e(__('Report Abuse')); ?>

                        </a> 
                    <?php endif; ?> 
                </div>
            <?php endif; ?>
        </div>

        <!-- Job Detail start -->
        <div class="row">
            <div class="col-md-8"> 
                <!-- About Employee start -->
                <div class="job-header">
                    <div class="contentbox">
                        <h3><?php echo e(__('About Company')); ?></h3>
                        <p><?php echo $company->description; ?></p>
                    </div>
                </div>

                <!-- Opening Jobs start -->
                <div class="relatedJobs">
                    <div class="titleTop">
                        <h3><?php echo e(__('Job')); ?> <span><?php echo e(__('Openings')); ?></span></h3>
                    </div>
                    <ul class="searchList">
                        <?php if(isset($company->jobs) && count($company->jobs)): ?>
                        <?php $__currentLoopData = $company->jobs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $companyJob): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                        <!--Job start-->
                        <li>
                            <div class="row">
                                <div class="col-md-8 col-sm-8">
                                    <div class="media">
                                        <div class="media-left">
                                            <div class="jobimg">
                                                <a href="<?php echo e(route('job.detail', [$companyJob->slug])); ?>" title="<?php echo e($companyJob->title); ?>"> 
                                                    <span style="background-image: url(<?php echo e($company->getCompanyImage()); ?>)"></span>
                                                </a>
                                            </div>
                                        </div>
                                        <div class="media-body">
                                            <div class="jobinfo">
                                                <h3><a href="<?php echo e(route('job.detail', [$companyJob->slug])); ?>" title="<?php echo e($companyJob->title); ?>"><?php echo e($companyJob->title); ?></a></h3>
                                                <div class="companyName"><a href="<?php echo e(route('company.detail', $company->slug)); ?>" title="<?php echo e($company->name); ?>"><?php echo e($company->name); ?></a></div>
                                                <div class="location">
                                                    <!-- <label class="partTime" title="<?php echo e($companyJob->getJobShift('job_shift')); ?>"><?php echo e($companyJob->getJobShift('job_shift')); ?></label> -->
                                                    <span><?php echo e($companyJob->getCity('city')); ?></span>
                                                </div>
                                                <div>
                                                    <label class="fulltime" title="<?php echo e($companyJob->getJobType('job_type')); ?>"><?php echo e($companyJob->getJobType('job_type')); ?></label>
                                                    <!-- <label class="partTime" title="<?php echo e($companyJob->getJobShift('job_shift')); ?>"><?php echo e($companyJob->getJobShift('job_shift')); ?></label> -->
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-4 col-sm-4">
                                    <div class="listbtn">
                                        <a class="btn btn-primary no-fill round text-uppercase" href="<?php echo e(route('job.detail', [$companyJob->slug])); ?>"><?php echo e(__('View Details')); ?></a>
                                    </div>
                                </div>
                            </div>
                            <p><?php echo e(str_limit(strip_tags($companyJob->description), 150, '...')); ?></p>
                        </li>
                        <!--Job end--> 
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php else: ?>
                            <div class="empty-state">
                                <span class="empty-state-icon job"></span>
                                <h4 class="empty-state-title">There are no job opening yet</h4>
                                <p></p>
                            </div>
                        <?php endif; ?> 

                        <!-- Job end -->
                    </ul>
                </div>
            </div>
            <div class="col-md-4"> 
                <!-- Company Detail start -->
                <div class="job-header">
                    <div class="jobdetail">
                        <h3><?php echo e(__('Company Details')); ?></h3>
                        <ul class="jbdetail">
                            <li class="row">
                                <div class="col-md-6 col-sm-6 col-xs-12"><?php echo e(__('Is Email Verified')); ?></div>
                                <div class="col-md-6 col-sm-6 col-xs-12"><span><?php echo e(((bool)$company->verified)? 'Yes':'No'); ?></span></div>
                            </li>
                            <li class="row">
                                <div class="col-md-6 col-sm-6 col-xs-12"><?php echo e(__('Total Employees')); ?></div>
                                <div class="col-md-6 col-sm-6 col-xs-12"><span><?php echo e($company->no_of_employees); ?></span></div>
                            </li>
                            <li class="row">
                                <div class="col-md-6 col-sm-6 col-xs-12"><?php echo e(__('Established In')); ?></div>
                                <div class="col-md-6 col-sm-6 col-xs-12"><span><?php echo e($company->established_in); ?></span></div>
                            </li>
                            <li class="row">
                                <div class="col-md-6 col-sm-6 col-xs-12"><?php echo e(__('Current jobs')); ?></div>
                                <div class="col-md-6 col-sm-6 col-xs-12"><span><?php echo e($company->countNumJobs('company_id',$company->id)); ?></span></div>
                            </li>
                        </ul>
                    </div>
                </div>

                <!-- Google Map start -->
                <!-- <?php if(NULL != $company->map): ?>
                    <div class="job-header">
                        <div class="jobdetail">
                            <h3>Map</h3>
                            <div class="gmap">
                                <?php echo $company->map; ?>

                            </div>
                        </div>
                    </div>
                <?php endif; ?> -->
                <div class="job-header">
                    <div class="jobdetail">
                        <h3>Map</h3>
                        <div class="gmap" id="map_canvas">
                            
                        </div>
                    </div>
                </div>

                <!-- Contact Company start -->
                <!-- <?php if(!Auth::guard('company')->check()): ?>
                <div class="job-header">
                    <div class="jobdetail">
                        <h3 id="contact_company"><?php echo e(__('Contact Company')); ?></h3>
                        <div id="alert_messages"></div>
                        <?php
                        $from_name = $from_email = $from_phone = $subject = $message = $from_id = '';
                        if (Auth::check()) {
                            $from_name = Auth::user()->name;
                            $from_email = Auth::user()->email;
                            $from_phone = Auth::user()->phone;
                            $from_id = Auth::user()->id;
                        }
                        $from_name = old('name', $from_name);
                        $from_email = old('email', $from_email);
                        $from_phone = old('phone', $from_phone);
                        $subject = old('subject');
                        $message = old('message');
                        ?>
                        <form method="post" id="send-company-message-form">
                            <?php echo e(csrf_field()); ?>

                            <input type="hidden" name="to_id" value="<?php echo e($company->id); ?>">
                            <input type="hidden" name="from_id" value="<?php echo e($from_id); ?>">
                            <input type="hidden" name="company_id" value="<?php echo e($company->id); ?>">
                            <input type="hidden" name="company_name" value="<?php echo e($company->name); ?>">
                            <div class="formpanel">
                                <div class="formrow">
                                    <input type="text" name="from_name" value="<?php echo e($from_name); ?>" class="form-control" required>
                                    <label>Your Name</label>
                                </div>
                                <div class="formrow">
                                    <input type="text" name="from_email" value="<?php echo e($from_email); ?>" class="form-control" required>
                                    <label>Your Email</label>
                                </div>
                                <div class="formrow">
                                    <input type="text" name="from_phone" value="<?php echo e($from_phone); ?>" class="form-control" required>
                                    <label>Phone</label>
                                </div>
                                <div class="formrow">
                                    <input type="text" name="subject" value="<?php echo e($subject); ?>" class="form-control" required>
                                    <label>Subject</label>
                                </div>
                                <div class="formrow">
                                    <textarea name="message" class="form-control" placeholder="Message"><?php echo e($message); ?></textarea>
                                </div>
                                <div class="formrow"><?php echo app('captcha')->display(); ?></div>
                                <div class="formrow">
                                    <input type="button" class="btn btn-secondary round" value="<?php echo e(__('Submit')); ?>" id="send_company_message">
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
                <?php endif; ?> -->
            </div>
        </div>
    </div>
</div>
<?php echo $__env->make('includes.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('styles'); ?>
<style type="text/css">
    .formrow iframe {
        height: 78px;
    }
</style>
<?php $__env->stopPush(); ?>
<?php $__env->startPush('scripts'); ?> 
<script type="text/javascript">
    $(document).ready(function () {
        $(document).on('click', '#send_company_message', function () {
            var postData = $('#send-company-message-form').serialize();
            $.ajax({
                type: 'POST',
                url: "<?php echo e(route('contact.company.message.send')); ?>",
                data: postData,
                //dataType: 'json',
                success: function (data)
                {
                    response = JSON.parse(data);
                    var res = response.success;
                    if (res == 'success')
                    {
                        var errorString = '<div role="alert" class="alert alert-success">' + response.message + '</div>';
                        $('#alert_messages').html(errorString);
                        $('#send-company-message-form').hide('slow');
                        $(document).scrollTo('.alert', 2000);
                    } else
                    {
                        var errorString = '<div class="alert alert-danger" role="alert"><ul>';
                        response = JSON.parse(data);
                        $.each(response, function (index, value)
                        {
                            errorString += '<li>' + value + '</li>';
                        });
                        errorString += '</ul></div>';
                        $('#alert_messages').html(errorString);
                        $(document).scrollTo('.alert', 2000);
                    }
                },
            });
        });
    });
</script>

<script type="text/javascript" async="" defer="">
        var geocoder;
        var map;
        // var overlay;
        // var usgsOverlay;
        var address ="<?php echo $company->location.','.$company->getCity('city').' '.$company->getState('state').','.$company->getCountry('country') ?>";
        
        function initMap() {
            geocoder = new google.maps.Geocoder();
            var latlng = new google.maps.LatLng(-34.397, 150.644);
            
            // USGSOverlay.prototype = new google.maps.OverlayView();

            var myOptions = {
                zoom: 16,
                center: latlng,
                disableDefaultUI: true,
                mapTypeControl: false,
                mapTypeControlOptions: {style: google.maps.MapTypeControlStyle.DROPDOWN_MENU},
                navigationControl: false,
                mapTypeId: google.maps.MapTypeId.ROADMAP
            };

            map = new google.maps.Map(document.getElementById("map_canvas"), myOptions);
            
            if (geocoder) {
                geocoder.geocode( { 'address': address}, function(results, status) {
                    if (status == google.maps.GeocoderStatus.OK) {
                        if (status != google.maps.GeocoderStatus.ZERO_RESULTS) {
                            map.setCenter(results[0].geometry.location);

                            var infowindow = new google.maps.InfoWindow({ 
                                content: '<b>'+address+'</b>',
                                size: new google.maps.Size(150,50)
                            });

                            var marker = new google.maps.Marker({
                                position: results[0].geometry.location,
                                map: map, 
                                title:address
                                // icon: '6096188ce806c80cf30dca727fe7c237.png'
                            }); 
                            google.maps.event.addListener(marker, 'click', function() {
                                infowindow.open(map,marker);
                            });

                        } else {
                            alert("No results found");
                        }
                    } else {
                        alert("Geocode was not successful for the following reason: " + status);
                    }
                });
            }
        }

        var textarea = document.querySelector('textarea');

        textarea.addEventListener('keydown', autosize);
                    
        function autosize(){
            var el = this;
            setTimeout(function(){
                el.style.cssText = 'height:auto; padding:0';
                // for box-sizing other than "content-box" use:
                // el.style.cssText = '-moz-box-sizing:content-box';
                el.style.cssText = 'height:' + el.scrollHeight + 'px';
            },0);
        }
</script>
<script async="" defer="" src="https://maps.googleapis.com/maps/api/js?key=AIzaSyAmiJ65xZEpp2SVHj56w-ih7qrSXUi4e3U&amp;callback=initMap">
        </script> 
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>