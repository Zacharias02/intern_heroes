<div class="section">
    <div class="container"> 
        <!-- title start -->
        <div class="titleTop align-center">
            <!-- <div class="subtitle"><?php echo e(__('Here You Can See')); ?></div> -->
            <h3><?php echo e(__('Success')); ?> <span><?php echo e(__('Stories')); ?></span></h3>
        </div>
        <!-- title end -->
        <div class="row">
            <div class="testimonials">
                <div class="col-md-6">
                    <div class="images">
                        <span class='step-3' style='background-image: url(https://www.icescrum.com/wp-content/uploads/2018/11/olivier_audouze.png)'></span>
                        <span class='step-2' style='background-image: url(https://www.icescrum.com/wp-content/uploads/2018/11/logo-airbus.png)'></span>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="qoute-icon">
                    </div>
                    <div class="texts">
                        <?php if(isset($testimonials) && count($testimonials)): ?>
                            <?php $__currentLoopData = $testimonials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $testimonial): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class=''>
                                <div class='text'><?php echo e($testimonial->testimonial); ?></div>
                                <div class='who'><?php echo e($testimonial->testimonial_by); ?></div>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    </div>
                    <div class="selectors">
                        <?php if(isset($testimonials) && count($testimonials)): ?>
                            <?php $__currentLoopData = $testimonials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $testimonial): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <span class=''></span>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
       <!--  <ul class="testimonialsList">
            <?php if(isset($testimonials) && count($testimonials)): ?>
            <?php $__currentLoopData = $testimonials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $testimonial): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li class="item">      
                <div class="row">
                    <div class="col-md-6">
                    </div>
                    <div class="col-md-6">
                        <p>"<?php echo e($testimonial->testimonial); ?>"</p>
                        <div class="clientname"><?php echo e($testimonial->testimonial_by); ?></div>
                        <div class="clientinfo"><?php echo e($testimonial->company); ?></div>
                    </div>
                </div>  
                
            </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
        </ul> -->
    </div>
</div>