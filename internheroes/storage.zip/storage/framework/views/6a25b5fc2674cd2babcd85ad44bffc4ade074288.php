<li class="nav-item  "> <a href="javascript:;" class="nav-link nav-toggle"> <i class="fa fa-line-chart" aria-hidden="true"></i> <span class="title">S.E.O</span> <span class="arrow"></span> </a>
    <ul class="sub-menu">
        <li class="nav-item  "> <a href="<?php echo e(route('list.seo')); ?>" class="nav-link "> <span class="title">List Pages</span> </a> </li>
    </ul>
</li>