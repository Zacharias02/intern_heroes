<h5 onclick="showSkills();"><?php echo e(__('Skills')); ?>

        <a href="javascript:;" onclick="showProfileSkillModal();" class="btn btn-primary no-fill round float-right"> 
                <i class="fa fa-plus-circle"></i>  <?php echo e(__('Add Skill')); ?> 
        </a>
</h5>
<div class="row">
    <div class="col-md-12">
        <div class="" id="skill_div"></div>
    </div>
</div>
<hr>
<div class="modal fade" id="add_skill_modal" role="dialog"></div>
<?php $__env->startPush('scripts'); ?> 
<script type="text/javascript">
    /**************************************************/
    function showProfileSkillModal(){
        $("#add_skill_modal").html('');
        $("#add_skill_modal").modal();
        loadProfileSkillForm();
    }
    function loadProfileSkillForm(){
    $.ajax({
    type: "POST",
            url: "<?php echo e(route('get.front.profile.skill.form', $user->id)); ?>",
            data: {"_token": "<?php echo e(csrf_token()); ?>"},
            datatype: 'json',
            success: function (json) {
            $("#add_skill_modal").html(json.html);
            }
    });
    }
    function showProfileSkillEditModal(skill_id){
        $("#add_skill_modal").html('');
        $("#add_skill_modal").modal();
        loadProfileSkillEditForm(skill_id);
    }
    function loadProfileSkillEditForm(skill_id){
    $.ajax({
        type: "POST",
        url: "<?php echo e(route('get.front.profile.skill.edit.form', $user->id)); ?>",
        data: {"skill_id": skill_id, "_token": "<?php echo e(csrf_token()); ?>"},
        datatype: 'json',
        success: function (json) {
                $("#add_skill_modal").html(json.html);
        }
    });
    }
    function submitProfileSkillForm() {
    var form = $('#add_edit_profile_skill');
    $.ajax({
        url     : form.attr('action'),
        type    : form.attr('method'),
        data    : form.serialize(),
        dataType: 'json',
        async: false,
        success : function (json){
                $ ("#add_skill_modal").html(json.html);
                showSkills();
        },
        error: function(json){
                if (json.status === 422) {
                        var resJSON = json.responseJSON;
                        $('.help-block').html('');
                        $.each(resJSON.errors, function (key, value) {
                                $('.' + key + '-error').html('<strong>' + value + '</strong>');
                                $('#div_' + key).addClass('has-error');
                        });
                } else {
                // Error
                // Incorrect credentials
                // alert('Incorrect credentials. Please try again.')
                }
        }
    });
    }
    function delete_profile_skill(id) {
    var msg = "<?php echo e(__('Are you sure you want to delete?')); ?>";
    if (confirm(msg)) {
    $.post("<?php echo e(route('delete.front.profile.skill')); ?>", {id: id, _method: 'DELETE', _token: '<?php echo e(csrf_token()); ?>'})
            .done(function (response) {
            if (response == 'ok')
            {
            $('#skill_' + id).remove();
            } else
            {
            alert('Request Failed!');
            }
            });
    }
    }
    $(document).ready(function(){
    showSkills();
    });
    function showSkills()
    {
    $.post("<?php echo e(route('show.front.profile.skills', $user->id)); ?>", {user_id: <?php echo e($user->id); ?>, _method: 'POST', _token: '<?php echo e(csrf_token()); ?>'})
            .done(function (response) {
            $('#skill_div').html(response);
            });
    }
</script> 
<?php $__env->stopPush(); ?>