
<?php $__env->startSection('content'); ?>
<table border="0" cellpadding="0" cellspacing="0" class="force-row" style="width: 100%;    border-bottom: solid 1px #ccc;">
    <tr>
        <td class="content-wrapper" style="padding-left:24px;padding-right:24px"><br>
            <div class="title" style="font-family: Helvetica, Arial, sans-serif; font-size: 18px;font-weight:400;color: #000;text-align: left;
                 padding-top: 20px;">Hi <?php echo e($user_name); ?>!</div></td>
    </tr>
    <tr>
        <td class="cols-wrapper" style="padding-left:12px;padding-right:12px"><!--[if mso]>
         <table border="0" width="576" cellpadding="0" cellspacing="0" style="width: 576px;">
            <tr>
               <td width="192" style="width: 192px;" valign="top">
                  <![endif]-->      
            <table border="0" cellpadding="0" cellspacing="0" align="left" class="force-row" style="width: 100%;">
                <tr>
                    <td class="row" valign="top" style="padding-left:12px;padding-right:12px;padding-top:18px;padding-bottom:12px"><table border="0" cellpadding="0" cellspacing="0" style="width:100%;">
                            <tr>
                                <td class="subtitle" style="font-family:Helvetica, Arial, sans-serif;font-size:14px;line-height:22px;font-weight:400;color:#333;padding-bottom:30px; text-align: left;">
                                    <p style="margin-bottom: 10px;">Thank you for submitting your application to <b><?php echo e($job_title); ?></b> and I am really excited for your next career.</p>
                                    <p>To see the details of the position you've applied, please click the link below:        
                                    <p>
                                        <br>
                                        Job details link :
                                        <span><a href="<?php echo e($job_link); ?>"><?php echo e($job_link); ?></a></span>
                                        <br>
                                        Employer/Company profile link : 
                                        <span><a href="<?php echo e($company_link); ?>"><?php echo e($company_link); ?></a></span>
                                        <br>
                                    </p>
                                </td>
                            </tr>
                            <tr>
                                <td style="font-family: Helvetica, Arial, sans-serif;font-size: 14px;line-height: 22px;font-weight: 400;color: #333; padding-bottom: 30px;text-align: left;">
                                Have a nice day ahead and wishing you good luck!
                                <br>
                                <br>
                                Sincerely,
                                <br>
                                BUDDIE
                                <br>
                                Jobbie’s Virtual Job Assistant
                                </td>
                            </tr>
                        </table>
                        <br></td>
                </tr>
            </table>      
            <!--[if mso]>
               </td>
            </tr>
         </table>
         <![endif]--></td>
    </tr>
</table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.email_template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>