<div class="modal-body">
    <div class="form-body">
        <div class="formrow" id="div_title">
            <input required class="form-control" id="title" name="title" type="text" value="<?php echo e((isset($profileExperience)? $profileExperience->title:'')); ?>">
            <label><?php echo e(__('Experience Title')); ?></label>
            <span class="help-block title-error" style="color: #a94442;"></span> </div>

        <div class="formrow" id="div_company">
            <input required class="form-control" id="company"  name="company" type="text" value="<?php echo e((isset($profileExperience)? $profileExperience->company:'')); ?>">
            <label><?php echo e(__('Company')); ?></label>
            <span class="help-block company-error"></span> </div>

        <div class="formrow hidden" id="div_country_id">
            <?php
            $country_id = (isset($profileExperience) ? $profileExperience->country_id : $siteSetting->default_country_id);
            ?>
            <?php echo Form::select('country_id', [''=>__('Select Country')]+$countries, $country_id, array('class'=>'form-control', 'id'=>'experience_country_id')); ?>

            <label><?php echo e(__('Country')); ?></label>
            <span class="help-block country_id-error"></span> </div>

        <div class="formrow" id="div_state_id">
            <span id="default_state_experience_dd">
                <?php echo Form::select('state_id', [''=>__('Select Province')], null, array('class'=>'form-control', 'id'=>'experience_state_id')); ?>


            </span>
            <span class="help-block state_id-error"></span> </div>

        <div class="formrow" id="div_city_id">
            <span id="default_city_experience_dd">
                <?php echo Form::select('city_id', [''=>__('Select City')], null, array('class'=>'form-control', 'id'=>'city_id')); ?>

            
            </span>
            <span class="help-block city_id-error"></span> </div>

        <div class="formrow" id="div_date_start">
            <input required class="form-control datepicker-experience-start"  autocomplete="off" id="date_start" name="date_start" type="text" value="<?php echo e((isset($profileExperience)? $profileExperience->date_start->format('Y-m-d'):'')); ?>">
            <label>Experience From</label>
            <span class="help-block date_start-error"></span> </div>
        <div class="formrow" id="div_date_end">
            <input required class="form-control datepicker-experience-end" autocomplete="off" id="date_end" name="date_end" type="text" value="<?php echo e((isset($profileExperience)? $profileExperience->date_end->format('Y-m-d'):'')); ?>">
            <label>Experience To</label>
            <span class="help-block date_end-error"></span> </div>
        <div class="formrow" id="div_is_currently_working">
            <label for="is_currently_working" class="bold"><?php echo e(__('Currently Working?')); ?></label>
            <div class="radio-list">
                <?php
                $val_1_checked = '';
                $val_2_checked = 'checked="checked"';

                if (isset($profileExperience) && $profileExperience->is_currently_working == 1) {
                    $val_1_checked = 'checked="checked"';
                    $val_2_checked = '';
                }
                ?>
                <label class="radio-inline"><input id="currently_working" name="is_currently_working" type="radio" value="1" <?php echo e($val_1_checked); ?>> <?php echo e(__('Yes')); ?> </label>
                <label class="radio-inline"><input id="not_currently_working" name="is_currently_working" type="radio" value="0" <?php echo e($val_2_checked); ?>> <?php echo e(__('No')); ?> </label>
            </div>
            <span class="help-block is_currently_working-error"></span>
        </div>
        <div class="formrow" id="div_description">
            <textarea maxlength="300" required name="description" class="form-control" id="description"><?php echo e((isset($profileExperience)? $profileExperience->description:'')); ?></textarea>
            <label>Experience description</label>
            <span class="help-block description-error"></span> </div>
    </div>
</div>