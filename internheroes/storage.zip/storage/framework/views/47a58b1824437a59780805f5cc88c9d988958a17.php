<div class="section">
    <div class="container"> 
        <!-- title start -->
        <div class="titleTop align-center">            
            <h3><?php echo e(__('Top')); ?> <span><?php echo e(__('Employers')); ?></span></h3>
        </div>
        <!-- title end -->

        <ul class="employerList">
            <!--employer-->
            <?php if(isset($topCompanyIds) && count($topCompanyIds)): ?>
            <?php $__currentLoopData = $topCompanyIds; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $company_id_num_jobs): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php
            $company = App\Company::where('id', '=', $company_id_num_jobs->company_id)->active()->first();
            if (null !== $company) {
                ?>
                <!-- data-toggle="tooltip" data-placement="bottom"  -->
                <li class="item" tdata-original-title="<?php echo e($company->name); ?>">
                    <a href="<?php echo e(route('company.detail', $company->slug)); ?>" title="<?php echo e($company->name); ?>">
                    <span style="background-image: url(<?php echo e($company->getCompanyImage()); ?>)"></span>
                    </a>
                </li>
                <?php
            }
            ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
        </ul>

    </div>    
</div>