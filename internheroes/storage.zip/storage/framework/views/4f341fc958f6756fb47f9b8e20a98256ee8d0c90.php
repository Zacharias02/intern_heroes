<div class="col-md-3 col-sm-4">
    <ul class="usernavdash">
        <li class="<?php echo e(Request::url() == route('company.home') ? 'active' : ''); ?>"><a href="<?php echo e(route('company.home')); ?>"><i class="fa fa-tachometer" aria-hidden="true"></i> <?php echo e(__('Dashboard')); ?></a></li>
        <li class="<?php echo e(Request::url() == url('/company-profile') ? 'active' : ''); ?>"><a href="<?php echo e(route('company.profile')); ?>"><i class="fa fa-user" aria-hidden="true"></i> <?php echo e(__('Update Company Profile')); ?></a></li>
        <li><a href="<?php echo e(route('company.detail', Auth::guard('company')->user()->slug)); ?>"><i class="fa fa-user" aria-hidden="true"></i> <?php echo e(__('View Company Profile')); ?></a></li>
        <li class="<?php echo e(Request::url() == url('/post-job') ? 'active' : ''); ?>"><a href="<?php echo e(route('post.job')); ?>"><i class="fa fa-desktop" aria-hidden="true"></i> <?php echo e(__('Post a Job')); ?></a></li>
        <li class="<?php echo e(Request::url() == url('/posted-jobs') ? 'active' : ''); ?>"><a href="<?php echo e(route('posted.jobs')); ?>"><i class="fa fa-desktop" aria-hidden="true"></i> <?php echo e(__('My Posted Jobs')); ?></a></li>

        <!-- <li class="<?php echo e(Request::url() == url('/company-messages') ? 'active' : ''); ?>"><a href="<?php echo e(route('company.messages')); ?>"><i class="fa fa-envelope-o" aria-hidden="true"></i> <?php echo e(__('Company Messages')); ?></a></li> -->
        <li class="<?php echo e(Request::url() == url('/company-followers') ? 'active' : ''); ?>"><a href="<?php echo e(route('company.followers')); ?>"><i class="fa fa-user-o" aria-hidden="true"></i> <?php echo e(__('My Followers')); ?></a></li>
        <li><a href="<?php echo e(route('company.logout')); ?>" onclick="event.preventDefault(); document.getElementById('logout-form').submit();"><i class="fa fa-sign-out" aria-hidden="true"></i> <?php echo e(__('Logout')); ?></a>
            <form id="logout-form" action="<?php echo e(route('company.logout')); ?>" method="POST" style="display: none;"><?php echo e(csrf_field()); ?></form>
        </li>
    </ul>
    <div class="row hidden-xs">
        <div class="col-md-12 sidebar-add">
            <?php echo $siteSetting->dashboard_page_ad; ?></div>
    </div>
</div>