<li class="nav-item  "> <a href="javascript:;" class="nav-link nav-toggle"> <i class="icon-briefcase"></i> <span class="title">Jobs</span> <span class="arrow"></span> </a>
    <ul class="sub-menu">
        <li class="nav-item  "> <a href="<?php echo e(route('list.jobs')); ?>" class="nav-link "> <span class="title">List Jobs</span> </a> </li>
        <li class="nav-item  "> <a href="<?php echo e(route('create.job')); ?>" class="nav-link "> <span class="title">Add new Job</span> </a> </li>
    </ul>
</li>