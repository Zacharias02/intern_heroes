
<?php $__env->startSection('content'); ?> 
<!-- Header start --> 
<?php echo $__env->make('includes.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?> 
<!-- Header end --> 
<!-- Inner Page Title start --> 
<?php echo $__env->make('includes.inner_page_title', ['page_title'=>__('My Messages')], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?> 
<!-- Inner Page Title end -->
<div class="listpgWraper">
    <div class="container">
        <div class="row"> <?php echo $__env->make('includes.user_dashboard_menu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <div class="col-md-9 col-sm-8">
                <div class="myads">
                    <h3><?php echo e(__('My Messages')); ?></h3>
                    <ul class="searchList">
                        <!-- job start --> 
                        <?php if(isset($messages) && count($messages)): ?>
                        <?php $__currentLoopData = $messages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        <?php
                        $style = (!(bool)$message->is_read)? 'border: 2px solid #FFB233;':'';
                        ?>

                        <li style="<?php echo e($style); ?>">
                            <a href="<?php echo e(route('applicant.message.detail', $message->id)); ?>" title="<?php echo e($message->subject); ?>">
                                <div class="row">
                                    <div class="col-md-8">              
                                        <h4><?php echo e($message->from_name); ?> - <?php echo e($message->from_email); ?></h4>
                                        <?php echo e($message->subject); ?>

                                    </div>
                                    <div class="col-md-4 text-right">
                                        <?php echo e($message->created_at->format('M d,Y')); ?>                
                                    </div>
                                </div>
                            </a>
                        </li>
                        <!-- job end --> 
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    </ul>
                    <?php if(count($messages) <= 0): ?>
                        <div class="empty-state">
                            <span class="empty-state-icon job"></span>
                            <h4 class="empty-state-title">No messages yet.</h4>
                            <p>No messages in your inbox yet.</p>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
    <?php echo $__env->make('includes.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php $__env->stopSection(); ?>
    <?php $__env->startPush('scripts'); ?>
    <?php echo $__env->make('includes.immediate_available_btn', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>