<div class="modal-dialog custom-modal"> 
    <!-- Modal content-->
    <div class="modal-content">
        <div class="modal-header" style="background: #d8ffef;">
            <span class="header-icon"></span>
            <button type="button" class="close" data-dismiss="modal">&times;</button>
            <h6 style="text-align: center;
    font-size: x-large;
    color: black;"><?php echo e(__('Your CV is added successfully')); ?></h6>
        </div>
<!--         <div class="modal-body">
            <div class="modal-caption" align="center">
                <h6><?php echo e(__('CV added successfully')); ?></h6>     
            </div>
        </div> -->
<!--         <div class="modal-footer">
            
        </div> -->
    </div>
</div>
