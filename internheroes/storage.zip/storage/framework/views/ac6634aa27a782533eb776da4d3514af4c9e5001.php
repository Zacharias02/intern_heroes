<li class="nav-item  "> <a href="javascript:;" class="nav-link nav-toggle"> <i class="fa fa-building"></i> <span class="title">Companies</span> <span class="arrow"></span> </a>
    <ul class="sub-menu">
        <li class="nav-item  "> <a href="<?php echo e(route('list.companies')); ?>" class="nav-link "> <span class="title">List Companies</span> </a> </li>
        <li class="nav-item  "> <a href="<?php echo e(route('create.company')); ?>" class="nav-link "> <span class="title">Add new Company</span> </a> </li>
    </ul>
</li>