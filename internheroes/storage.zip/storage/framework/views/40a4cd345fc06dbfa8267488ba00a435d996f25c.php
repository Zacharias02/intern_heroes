
<?php $__env->startSection('content'); ?> 
<!-- Header start --> 
<?php echo $__env->make('includes.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?> 
<!-- Header end --> 
<!-- Inner Page Title start --> 
<?php echo $__env->make('includes.inner_page_title', ['page_title'=>__('Company Messages')], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?> 
<!-- Inner Page Title end -->
<div class="listpgWraper">
    <div class="container">
        <div class="row"> <?php echo $__env->make('includes.company_dashboard_menu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <div class="col-md-9 col-sm-8">
                <div class="myads">
                    <h3><?php echo e(__('Company Messages')); ?></h3>
                    <div class="panel-group"> 
                        <!-- job start --> 
                        <?php if(isset($message)): ?>
                        <div class="panel panel-info">
                            <div class="panel-body">
                                <p class="text-left"></p>
                                <table>
                                    <tr>
                                        <td><?php echo e(__('Date')); ?> : </td>
                                        <td>&nbsp;&nbsp;&nbsp;</td>
                                        <td><?php echo e($message->created_at->format('M d,Y')); ?></td>
                                    </tr>
                                    <tr>
                                        <td><?php echo e(__('From')); ?> : </td>
                                        <td>&nbsp;&nbsp;&nbsp;</td>
                                        <td><?php echo e($message->from_name); ?> - <a href="<?php echo e(url('user-profile/'.$message->from_id.'#contact_applicant')); ?>" target="_blank"><?php echo e($message->from_email); ?></a></td>
                                    </tr>
                                    <tr>
                                        <td><?php echo e(__('Subject')); ?> : </td>
                                        <td>&nbsp;&nbsp;&nbsp;</td>
                                        <td><?php echo e($message->subject); ?></td>
                                    </tr>
                                    <tr>
                                        <td><?php echo e(__('Message')); ?> : </td>
                                        <td>&nbsp;&nbsp;&nbsp;</td>
                                        <td><?php echo e($message->message_txt); ?></td>
                                    </tr>
                                </table>
                                <a style="margin-top: 20px;" class="btn btn-secondary round" href="<?php echo e(url('user-profile/'.$message->from_id.'#contact_applicant')); ?>" target="_blank">Reply</a>
                            </div>
                        </div>
                        <!-- job end --> 
                        <?php endif; ?> </div>
                </div>
            </div>
        </div>
    </div>
    <?php echo $__env->make('includes.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>