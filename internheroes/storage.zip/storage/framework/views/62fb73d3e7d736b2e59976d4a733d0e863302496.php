<div class="modal-dialog custom-modal"> 
    <!-- Modal content-->
    <div class="modal-content">
        <div class="modal-header">
            <span class="header-icon"></span>
            <button type="button" class="close" data-dismiss="modal">&times;</button>
        </div>
        <div class="modal-body">
            <div class="modal-caption">
                <h5><?php echo e(__('Add Experience')); ?></h5>                
                <p><?php echo e(__('Experience added successfully')); ?></p>     
            </div>
        </div>
<!--         <div class="modal-footer">
            
        </div> -->
    </div>
</div>
