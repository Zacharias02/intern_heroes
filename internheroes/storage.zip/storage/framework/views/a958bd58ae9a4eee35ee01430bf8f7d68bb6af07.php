<div class="header">
    <div class="container">
        <div class="row">
            <div class="col-md-2 col-sm-12 col-xs-12"> <a href="<?php echo e(url('/')); ?>" class="logo"><img src="<?php echo e(asset('/')); ?>sitesetting_images/thumb/<?php echo e($siteSetting->site_logo); ?>" alt="<?php echo e($siteSetting->site_name); ?>" /></a>
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse"> <span class="sr-only">Toggle navigation</span> <span class="icon-bar"></span> <span class="icon-bar"></span> <span class="icon-bar"></span> </button>
                </div>
                <div class="clearfix"></div>
            </div>
            <div class="col-md-10 col-sm-12 col-xs-12"> 

                <!-- Nav start -->

                <div class="navbar navbar-default" role="navigation">
                    <div class="navbar-collapse collapse" id="nav-main">
                        <ul class="nav navbar-nav">
                            <li class="<?php echo e(Request::url() == route('index') ? 'active' : ''); ?>"><a href="<?php echo e(url('/')); ?>"><?php echo e(__('Home')); ?></a> </li>
                            <li class="<?php echo e(Request::url() == url('/jobs') ? 'active' : ''); ?>"><a href="<?php echo e(url('/jobs')); ?>"><?php echo e(__('Browse Jobs')); ?></a> </li>
                            <?php if(Auth::guard('company')->check()): ?>
                                <li id="jobseekers_1" class="<?php echo e(Request::url() == url('/job-seekers') ? 'active' : ''); ?>"><a href="<?php echo e(url('/job-seekers')); ?>"><?php echo e(__('Job Seekers')); ?></a> </li>
                            <?php endif; ?>
                            <li id="companies_1" class="<?php echo e(Request::url() == url('/companies') ? 'active' : ''); ?>" id="companies"><a href="<?php echo e(url('/companies')); ?>"><?php echo e(__('Companies')); ?></a> </li>
                            <li class="dropdown">

                                <a href="#"><?php echo e(__('More')); ?> <span class="caret"></span></a> 
                                <!-- dropdown start -->
                                <ul class="dropdown-menu">
                                    <?php if(Auth::guard('company')->check()): ?>
                                    <li id="jobseekers" style="display:none;" class="<?php echo e(Request::url() == url('/job-seekers') ? 'active' : ''); ?>"><a href="<?php echo e(url('/job-seekers')); ?>"><?php echo e(__('Job Seekers')); ?></a> </li>
                                    <?php endif; ?> 
                                    <li id="companies" style="display:none;" class="<?php echo e(Request::url() == url('/companies') ? 'active' : ''); ?>" id="companies"><a href="<?php echo e(url('/companies')); ?>"><?php echo e(__('Companies')); ?></a> </li>
                                    <li id="contact_us" style="display:none;" class="<?php echo e(Request::url() == route('contact.us') ? 'active' : ''); ?>" id="conctact_Us"><a href="<?php echo e(route('contact.us')); ?>"><?php echo e(__('Contact us')); ?></a> </li>
                                    <li id="contact_us_1" class="<?php echo e(Request::url() == route('contact.us') ? 'active' : ''); ?>" id="conctact_Us"><a href="<?php echo e(route('contact.us')); ?>"><?php echo e(__('Contact us')); ?></a> </li>
                                    <?php $__currentLoopData = $show_in_top_menu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $top_menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php $cmsContent = App\CmsContent::getContentBySlug($top_menu->page_slug); ?>
                                    <li class="<?php echo e(Request::url() == url('/cms/'.$top_menu->page_slug) ? 'active' : ''); ?>"><a href="<?php echo e(route('cms', $top_menu->page_slug)); ?>"><?php echo e($cmsContent->page_title); ?></a> </li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                                <!-- dropdown end --> 
                            </li>
                            <?php if(Auth::check()): ?>
                            <li class="dropdown userbtn">
                                <a class="header-profile-image" href="">
                                    <span style="background-image: url(<?php echo e(Auth::user()->getUserImage()); ?>);"></span>
                                </a>
                                <ul class="dropdown-menu">
                                    <li><a href="<?php echo e(route('home')); ?>"><i class="fa fa-tachometer" aria-hidden="true"></i> <?php echo e(__('Dashboard')); ?></a> </li>
                                    <li><a href="<?php echo e(route('my.profile')); ?>"><i class="fa fa-user" aria-hidden="true"></i> <?php echo e(__('My Profile')); ?></a> </li>
                                    <li><a href="<?php echo e(route('view.public.profile', Auth::user()->id)); ?>"><i class="fa fa-eye" aria-hidden="true"></i> <?php echo e(__('View Public Profile')); ?></a> </li>
                                    <li><a href="<?php echo e(route('my.job.applications')); ?>"><i class="fa fa-desktop" aria-hidden="true"></i> <?php echo e(__('My Job Applications')); ?></a> </li>
                                    <li><a href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault(); document.getElementById('logout-form-header').submit();"><i class="fa fa-sign-out" aria-hidden="true"></i> <?php echo e(__('Logout')); ?></a> </li>
                                    <form id="logout-form-header" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                                        <?php echo e(csrf_field()); ?>

                                    </form>
                                </ul>
                            </li>
                            <?php endif; ?> <?php if(Auth::guard('company')->check()): ?>
                            <li class="postjob"><a href="<?php echo e(route('post.job')); ?>"><?php echo e(__('Post a job')); ?></a> </li>
                            <li class="dropdown userbtn">
                                <a class="header-profile-image" href="#">
                                    <span style="background-image: url(<?php echo e(Auth::guard('company')->user()->getCompanyImage()); ?>)"></span>
                                </a>
                                <ul class="dropdown-menu">
                                    <li><a href="<?php echo e(route('company.home')); ?>"><i class="fa fa-tachometer" aria-hidden="true"></i> <?php echo e(__('Dashboard')); ?></a> </li>
                                    <li><a href="<?php echo e(route('company.profile')); ?>"><i class="fa fa-user" aria-hidden="true"></i> <?php echo e(__('Update Company Profile')); ?></a></li>
                                    <li><a href="<?php echo e(route('post.job')); ?>"><i class="fa fa-desktop" aria-hidden="true"></i> <?php echo e(__('Post a Job')); ?></a></li>
                                    <!-- <li><a href="<?php echo e(route('company.messages')); ?>"><i class="fa fa-envelope-o" aria-hidden="true"></i> <?php echo e(__('Company Messages')); ?></a></li> -->
                                    <li><a href="<?php echo e(route('company.logout')); ?>" onclick="event.preventDefault(); document.getElementById('logout-form-header1').submit();"><?php echo e(__('Logout')); ?></a> </li>
                                    <form id="logout-form-header1" action="<?php echo e(route('company.logout')); ?>" method="POST" style="display: none;">
                                        <?php echo e(csrf_field()); ?>

                                    </form>
                                </ul>
                            </li>
                            <?php endif; ?> <?php if(!Auth::user() && !Auth::guard('company')->user()): ?>
                            <li class="postjob dropdown">
                            <a href="#"><?php echo e(__('Login')); ?> <span class="caret"></span></a> 

                                <!-- dropdown start -->

                                <ul class="dropdown-menu">
                                    <li><a href="<?php echo e(route('login')); ?>"><?php echo e(__('Login')); ?></a> </li>
                                    <li><a href="<?php echo e(route('register')); ?>"><?php echo e(__('Register')); ?></a> </li>
                                </ul>

                                <!-- dropdown end --> 

                            </li>
                            <?php endif; ?>
                            <!-- <li class="dropdown userbtn"><a href="<?php echo e(url('/')); ?>"><img src="<?php echo e(asset('/')); ?>images/lang.png" alt="" class="userimg" /></a>
                                <ul class="dropdown-menu">
                                    <?php $__currentLoopData = $siteLanguages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $siteLang): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><a href="javascript:;" onclick="event.preventDefault(); document.getElementById('locale-form-<?php echo e($siteLang->iso_code); ?>').submit();"><?php echo e($siteLang->native); ?></a>
                                        <form id="locale-form-<?php echo e($siteLang->iso_code); ?>" action="<?php echo e(route('set.locale')); ?>" method="POST" style="display: none;">
                                            <?php echo e(csrf_field()); ?>

                                            <input type="hidden" name="locale" value="<?php echo e($siteLang->iso_code); ?>"/>
                                            <input type="hidden" name="return_url" value="<?php echo e(url()->full()); ?>"/>
                                            <input type="hidden" name="is_rtl" value="<?php echo e($siteLang->is_rtl); ?>"/>
                                        </form>
                                    </li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </li> -->
                        </ul>

                        <!-- Nav collapes end --> 

                    </div>
                    <div class="clearfix"></div>
                </div>

                <!-- Nav end --> 

            </div>
        </div>

        <!-- row end --> 

    </div>

    <!-- Header container end --> 

</div>
